const api = require('../lib/api');
const output = require('../lib/output');
const fs = require('fs');
const path = require('path');

async function uploadFile(filePath, fileType, description) {
  if (!fs.existsSync(filePath)) {
    console.error('错误：文件不存在 - ' + filePath);
    process.exit(1);
  }
  const stats = fs.statSync(filePath);
  if (stats.size > 10 * 1024 * 1024) {
    console.error('错误：文件超过 10MB 大小限制');
    process.exit(1);
  }

  const signRes = await api.get('/api/admin/oss/signature', { type: fileType });
  const sign = signRes.data || signRes;

  const ext = path.extname(filePath);
  const timestamp = Date.now();
  const randomId = Math.floor(Math.random() * 900) + 100;
  const objectKey = sign.dir + timestamp + '-' + randomId + ext;
  const objectUrl = '/' + objectKey;
  const fileContent = fs.readFileSync(filePath);

  const FormData = require('form-data');
  const form = new FormData();
  form.append('key', objectKey);
  form.append('OSSAccessKeyId', sign.accessid);
  form.append('policy', sign.policy);
  form.append('signature', sign.signature);
  form.append('file', fileContent, { filename: 'upload' + ext });

  const axios = require('axios');
  const uploadRes = await axios.post(sign.host, form, {
    headers: form.getHeaders(),
    maxContentLength: 10 * 1024 * 1024,
    maxBodyLength: 10 * 1024 * 1024,
  });

  if (uploadRes.status !== 204 && uploadRes.status !== 200) {
    console.error('错误：上传到 OSS 失败（' + uploadRes.status + '）');
    process.exit(1);
  }

  const baseUrl = sign.host;
  await api.post('/api/admin/oss/register', {
    url: objectUrl,
    fileName: objectKey.replace(sign.dir, ''),
    fileSize: stats.size,
    mimeType: getMimeType(ext),
    description: description || 'CLI 上传',
  });

  // 博客前台使用的是自定义 CDN 域名（oss.base_url），非 Aliyun 直链
  // 拿到后可直接用于 project --images / article --cover
  let cdnUrl = null;
  try {
    const cfgRes = await api.get('/api/admin/config/system');
    const cfg = cfgRes.data || cfgRes;
    const cdnBase = cfg && cfg['oss.base_url'];
    if (cdnBase) cdnUrl = cdnBase.replace(/\/+$/, '') + objectUrl;
  } catch (e) {
    // 读不到配置就算了，url 和 fullUrl 仍可用
  }

  return {
    url: objectUrl,
    fullUrl: baseUrl + objectUrl,
    cdnUrl: cdnUrl,
    fileName: objectKey.replace(sign.dir, ''),
    fileSize: stats.size,
  };
}

function getMimeType(ext) {
  const map = {
    '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.png': 'image/png',
    '.gif': 'image/gif', '.webp': 'image/webp', '.svg': 'image/svg+xml', '.bmp': 'image/bmp',
  };
  return map[ext.toLowerCase()] || 'application/octet-stream';
}

function register(program) {
  const cmd = program.command('oss')
    .description('资源管理（OSS）');

  cmd.command('list')
    .description('获取资源列表')
    .option('--page <page>', '页码', '1')
    .option('--size <size>', '每页条数', '20')
    .action(async (options) => {
      const res = await api.get('/api/admin/oss/list', { page: options.page, size: options.size });
      output.success(res.data || res);
    });

  cmd.command('upload')
    .description('上传本地图片到 OSS')
    .requiredOption('--file <path>', '本地文件路径')
    .option('--type <type>', '类型：article/cover/avatar/project/config/default', 'default')
    .option('--desc <desc>', '资源描述')
    .action(async (options) => {
      const result = await uploadFile(options.file, options.type, options.desc);
      output.successWithMessage(result, '图片已上传到 OSS');
    });
}

module.exports = { register };
